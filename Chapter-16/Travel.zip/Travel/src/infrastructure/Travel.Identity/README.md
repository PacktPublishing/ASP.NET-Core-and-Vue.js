


### Azure Key Vault
- needs an Azure Account

### Microsoft Identity
- 

### Auth0
- An identity as a Service that saves you time and money in development

### Identity Server
- A robust OAuth2 and OIDC framework that saves you time in development.