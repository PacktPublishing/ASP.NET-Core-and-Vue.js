namespace Travel.Identity.Helpers
{
    public class AuthSettings
    {
        public string Secret { get; set; }
    }
}