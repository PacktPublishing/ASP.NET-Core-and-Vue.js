﻿namespace Travel.Application.Dtos.Tour
{
  public class CurrencyDto
  {
    public int Value { get; set; }
    public string Name { get; set; }
  }
}