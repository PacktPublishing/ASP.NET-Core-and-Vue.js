﻿namespace Travel.Domain.Enums
{
  public enum Currency
  {
    PHP,
    USD,
    JPY,
    EUR,
    NOK
  }
}
